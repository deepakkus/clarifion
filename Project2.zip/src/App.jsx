import { useState } from 'react'
import './App.css'
import Page from './Components/Page/Page';

function App() {

  return (
    <>
       <Page></Page>
    </>
  )
}

export default App
